<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Tambah Spesialisasi</h1>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('spesialisasi.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="nama_spesialisasi" class="form-label">Nama Spesialisasi</label>
                <input type="text" class="form-control" id="nama_spesialisasi" name="nama_spesialisasi">
            </div>
            <div class="mb-3">
                <label for="tingkatan" class="form-label">Tingkatan</label>
                <input type="text" class="form-control" id="tingkatan" name="tingkatan">
            </div>
            <div class="mb-3">
                <label for="deskripsi_singkat" class="form-label">Deskripsi Singkat</label>
                <textarea class="form-control" id="deskripsi_singkat" name="deskripsi_singkat"></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Tambah Spesialisasi</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nehru Iliomar\OneDrive\Documents\Semester 4\Pemrograman Web\Hexsam\solbat\resources\views/make_spesialisasi.blade.php ENDPATH**/ ?>