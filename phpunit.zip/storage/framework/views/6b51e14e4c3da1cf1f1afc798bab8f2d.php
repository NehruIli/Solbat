<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="container">
        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-8"><h2>Approval<b></b></h2></div>
                </div>
            </div>
            <table class="table table-bordered">
                    <thead class="text-center">
                    <tr>
                        <th>No.</th>
                        <th>Nama Bantuan</th>
                        <th>Pemberi Bantuan</th>
                        <th>Biaya Awal</th>
                        <th>Tawaran Biaya</th>
                        <th>Status</th>
                        <th>Aksi</th>

                    </tr>
                </thead>
                <tbody class="text-center justify-content-center" >

                    <?php $__currentLoopData = $penawaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($b->bantuan->bantuan); ?></td>
                        <td><?php echo e($b->user->nama_depan); ?> <?php echo e($b->user->nama_belakang); ?></td>
                        <td>Rp. <?php echo e($b->bantuan->biaya); ?></td>
                        <td>Rp. <?php echo e($b->biaya_penawaran); ?></td>
                        <td><?php echo e($b->status); ?></td>
                        <td>
                            <form action="<?php echo e(route('approved', $b->penawaran_bantuan_id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>
                                <button type="submit" class="btn btn-success">✅</button>
                            </form>
                            <form action="<?php echo e(route('reject', $b->penawaran_bantuan_id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>
                                <button type="submit" class="btn btn-danger">❌</button>
                            </form>
                            
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

            </table>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nehru Iliomar\OneDrive\Documents\Semester 4\Pemrograman Web\Hexsam\solbat\resources\views/approval.blade.php ENDPATH**/ ?>