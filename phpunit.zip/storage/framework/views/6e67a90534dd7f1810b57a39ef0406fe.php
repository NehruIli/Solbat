<?php $__env->startSection('content'); ?>

<body class="bg-primary">
    <div id="layoutAuthentication">
        <div id="layoutAuthentication_content">
            <main>
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-7">
                            <div class="card shadow-lg border-0 rounded-lg mt-5">
                                <div class="card-header"><h3 class="text-center font-weight-light my-4">Buat Spesialisasi Anda</h3></div>
                                <div class="card-body">
                                   <?php if(session()->has('errors')): ?>
                                   <?php $__currentLoopData = session('errors')->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <p><?php echo e($e); ?></p>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   <?php endif; ?>
                                    <form method="post" action="<?php echo e(route('edit_spesialis',$spesialis->id)); ?>">
                                         <?php echo csrf_field(); ?>
                                         <div class="form-floating mb-3">
                                            <input class="form-control" id="bantuan" type="text"placeholder="Masukkan namma spesialisasi" name="nama_spesialisasi" />
                                            <label for="bantuan">Nama Spesialisasi</label>
                                        </div>
                                        <div class="form-floating mb-3">
                                            <input class="form-control" id="bantuan" type="text"placeholder="Masukkan tingkatan" name="tingkatan" />
                                            <label for="bantuan">Tingkatan</label>
                                        </div>
                                        <div class="form-floating mb-3">
                                            <textarea class="form-control" id="deskripsi_singkat" type="text" minlength="12" maxlength="255" placeholder="Masukkan alamat detail bantuan" name="deskripsi_singkat" ></textarea>
                                            <label for="deskripsi_singkat">Deskripsi Singkat</label>
                                        </div>
                                        <div class="mt-4 mb-0">
                                            <div class="d-grid"><button type="submit" class="btn btn-primary btn-block">Buat Spesialisasi</button></div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>
</body>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nehru Iliomar\OneDrive\Documents\Semester 4\Pemrograman Web\Hexsam\solbat\resources\views/edit_spesialisasi.blade.php ENDPATH**/ ?>