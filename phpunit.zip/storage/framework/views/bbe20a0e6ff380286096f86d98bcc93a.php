<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="main-body">

          <div class="row gutters-sm">
            <div class="col-md-4 mb-3">
              <div class="card">
                <div class="card-body">
                  <div class="d-flex flex-column align-items-center text-center">
                    <img src="<?php echo e(asset('storage/'.Auth::user()->img_user)); ?>" alt="User" class="rounded-circle" width="150" height="200">
                    <div class="mt-3">
                        <p class="text-muted mb-1"><?php echo e(Auth::user()->nama_depan . ' '. Auth::user()->nama_belakang); ?></p>
                        <p class="text-muted mb-1"><?php echo e(Auth::user()->pekerjaan); ?></p>
                    </div>
                  </div>
                </div>
              </div>
              <br>

            </div>
           <div class="col-md-8">
                <div class="card mb-3">
                  <form action="<?php echo e(route('submit_profile', Auth::user()->user_id)); ?>" method="post"><div class="card-body">
                  <?php echo csrf_field(); ?>
                    <div class="row">
                      <div class="col-sm-3">
                        <h6 class="mb-0">Name Lengkap</h6>
                      </div>
                      <div class="col-sm-9 text-muted">
                        <?php echo e(Auth::user()->nama_depan . ' '. Auth::user()->nama_belakang); ?>

                      </div>
                    </div>
                    <hr>
                    <div class="row">
                      <div class="col-sm-3">
                        <h6 class="mb-0">Email</h6>
                      </div>
                      <div class="col-sm-9 text-muted">
                        <?php echo e(Auth::user()->email); ?>

                      </div>
                    </div>
                    <hr>
                    <div class="row">
                      <div class="col-sm-3">
                        <h6 class="mb-0">Nomer Handphone</h6>
                      </div>
                      <div class="col-sm-9 text-muted">
                          <input class="form-control" id="no_telepon" type="text" placeholder="Masukkan kemampuan anda secara detail." name="no_telepon" value="<?php echo e(Auth::user()->no_telepon); ?>">
                      </div>
                    </div>
                    <hr>
                    <div class="row">
                      <div class="col-sm-3">
                        <h6 class="mb-0">Alamat</h6>
                      </div>
                      <div class="col-sm-9 text-muted">
                        
                        <input class="form-control" id="alamat" type="text" placeholder="Masukkan kemampuan anda secara detail." name="alamat" value="<?php echo e(Auth::user()->alamat); ?>">
                      </div>
                    </div>
                    <hr>
                    <?php if(Auth::user()->kemampuan_detail != null): ?>

                    <div class="row">
                        <div class="col-sm-3">
                          <h6 class="mb-0">Kemampuan Detail</h6>
                        </div>
                        <div class="col-sm-9 text-muted">
                            <textarea class="form-control" id="kemampuan_detail" type="textarea" placeholder="Masukkan kemampuan anda secara detail." name="kemampuan_detail"><?php echo e(Auth::user()->kemampuan_detail); ?></textarea>
                        </div>
                    </div>
                    <?php else: ?>
                    <div class="row">
                        <div class="col-sm-3">
                          <h6 class="mb-0">Kemampuan Detail</h6>
                        </div>
                        <div class="col-sm-9 text-muted">
                            <textarea class="form-control" id="kemampuan_detail" type="textarea" placeholder="Masukkan kemampuan anda secara detail." name="kemampuan_detail"></textarea>
                        </div>
                    </div>

                    <?php endif; ?>
                    <hr>
                    <div class="col-sm-4">
                      <button type="submit" class="btn btn-info add-new" >Submit</button>
                  </div></form>
                </div>
            </div>
            <br>
            <div class="card">
                <div class="container">
                    <div class="table-wrapper">
                        <div class="table-title">
                            <div class="row">
                                <div class="col-sm-8"><h2>Spesialisasi<b></b></h2></div>
                                    <div class="col-sm-4 mt-2">
                                        <a href="<?php echo e(route('make_spesialisasi')); ?>"" type="button" class="btn btn-info add-new"><i class="fa fa-plus" "></i> New</a>
                                    </div>
                                    <br>
                                </div>
                            </div>
                            <table class="table table-bordered">
                                <thead class="text-center">
                                    <tr>
                                        <th>No.</th>
                                        <th>Spesialisasi</th>
                                        <th>Tingkatan</th>
                                        <th>Deskripsi Singkat</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody class="text-center justify-content-center" >

                                    <?php $__currentLoopData = $spesialisasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($s->nama_spesialisasi); ?></td>
                                        <td><?php echo e($s->tingkatan); ?></td>
                                        <td><?php echo e($s->deskripsi_singkat); ?></td>
                                        <td>
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <a href="<?php echo e(route('spesialisasi.edit', $s->spesialisasi_id)); ?>" class="edit btn" title="Edit" data-toggle="tooltip">✏️</a>
                                                </div>
                                                <div class="col-md-4">
                                                    <form action="<?php echo e(route('spesialisasi.destroy', $s->spesialisasi_id)); ?>" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('delete'); ?>
                                                        <button type="submit" class="delete btn">🗑️</button>
                                                    </form>
                                                </div>
                                            </div>
                                                
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>

                            </table>
                            <br>



                        </div>
                    </div>
                </div>

                <br>


            </div>
        </div>
      </div>
    </div>
  </div>


              </div>
          </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nehru Iliomar\OneDrive\Documents\Semester 4\Pemrograman Web\Hexsam\solbat\resources\views/profile.blade.php ENDPATH**/ ?>