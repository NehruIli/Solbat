@extends('layout')

@section('content')
    <!-- Header Start -->
    <div class="jumbotron jumbotron-fluid page-header position-relative overlay-bottom" style="margin-bottom: 90px;">
        <div class="container text-center py-5">
            <h1 class="text-white display-1">Agents</h1>
            <div class="d-inline-flex text-white mb-5">
                <p class="m-0 text-uppercase"><a class="text-white" href="index.html">Home</a></p>
                <i class="fa fa-angle-double-right pt-1 px-3"></i>
                <p class="m-0 text-uppercase">Agents</p>
            </div>
            <div class="mx-auto mb-5" style="width: 100%; max-width: 600px;">
                <div class="input-group">
                    <!-- <div class="input-group-prepend">
                        <button class="btn btn-outline-light bg-white text-body px-4 dropdown-toggle" type="button" data-toggle="dropdown"
                            aria-haspopup="true" aria-expanded="false">Courses</button>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="#">Courses 1</a>
                            <a class="dropdown-item" href="#">Courses 2</a>
                            <a class="dropdown-item" href="#">Courses 3</a>
                        </div>
                    </div> -->
                    <input type="text" class="form-control border-light" style="padding: 30px 25px;"
                        placeholder="Keyword">
                    <div class="input-group-append">
                        <button class="btn btn-secondary px-4 px-lg-5">Search</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Header End -->


    <!-- Team Start -->
    <div class="container-fluid py-5">
        <div class="container py-5">
            <div class="section-title text-center position-relative mb-5">
                <h6 class="d-inline-block position-relative text-secondary text-uppercase pb-2">Agent</h6>
                <h1 class="display-4">Meet Our Agent</h1>
            </div>
            <div class="row">
                @foreach ($dataAgent as $d)
                <div class="col-3">
                    <div class="team-item">
                        <img class="img-fluid w-100" src="img/Agent.Dio Pamungkas.jpg" alt="">
                        <div class="bg-light text-center p-4">
                            <h5 class="mb-3">{{$d->nama_depan . ' '. $d->nama_belakang}}</h5>
                            <p class="mb-2">{{$d->pekerjaan}}</p>
                            <div class="d-flex justify-content-center">
                                <a class="btn btn-primary" href="{{route('agent_detail', $d->user_id)}}">Agent Detail</a>
                        </div>
                    </div>
                </div>

            </div>
            @endforeach
            {{-- <div class="owl-carousel team-carousel position-relative" style="padding: 0 30px;">
                <div class="team-item">
                    <img class="img-fluid w-100" src="img/Agent.Dio Pamungkas.jpg" alt="">
                    <div class="bg-light text-center p-4">
                        <h5 class="mb-3">Dio Pamungkas</h5>
                        <p class="mb-2">Mekanik Listrik</p>
                        <div class="d-flex justify-content-center">
                            <a class="mx-1 p-1" href="#"><i class="fab fa-twitter"></i></a>
                            <a class="mx-1 p-1" href="#"><i class="fab fa-facebook-f"></i></a>
                            <!-- <a class="mx-1 p-1" href="#"><i class="fab fa-linkedin-in"></i></a> -->
                            <a class="mx-1 p-1" href="#"><i class="fab fa-instagram"></i></a>
                            <a class="mx-1 p-1" href="#"><i class="fab fa-whatsapp"></i></a>
                            <!-- <a class="mx-1 p-1" href="#"><i class="fab fa-youtube"></i></a> -->
                        </div>
                    </div>
                </div>
            </div> --}}
        </div>
    </div>
    </div>
    </div>
    <!-- Team End -->
@endsection
