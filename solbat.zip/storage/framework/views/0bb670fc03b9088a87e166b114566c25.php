<?php $__env->startSection('content'); ?>

    <body class="bg-primary">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-7">
                                <div class="card shadow-lg border-0 rounded-lg mt-5">
                                    <div class="card-header"><h3 class="text-center font-weight-light my-4">Update Spesialisasi</h3></div>
                                    <div class="card-body">
                                    <?php if(session()->has('errors')): ?>
                                    <?php $__currentLoopData = session('errors')->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p><?php echo e($e); ?></p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                        <form method="post" action="<?php echo e(route('spesialisasi.update', $spesialisasi->spesialisasi_id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('put'); ?>
                                            <select class="form-select mb-3" aria-label="Default select example" name="nama_spesialisasi">
                                                <option selected><?php echo e($spesialisasi->nama_spesialisasi); ?></option>
                                                <option value="Otomotif" <?php echo e($spesialisasi->nama_spesialisasi == 'Otomotif' ? 'required' : ''); ?>>Otomotif</option>
                                                <option value="Alat Elektronik" <?php echo e($spesialisasi->nama_spesialisasi == 'Alat Elektronik' ? 'required' : ''); ?>>Alat Elektronik</option>
                                                <option value="Properti" <?php echo e($spesialisasi->nama_spesialisasi == 'Properti' ? 'required' : ''); ?>>Properti</option>
                                                <option value="Pekerjaan Fisik" <?php echo e($spesialisasi->nama_spesialisasi == 'Pekerjaan Fisik' ? 'required' : ''); ?>>Pekerjaan Fisik</option>
                                                <option value="Mengajar" <?php echo e($spesialisasi->nama_spesialisasi == 'Mengajar' ? 'required' : ''); ?>>Mengajar</option>
                                                <option value="Makanan & Minuman" <?php echo e($spesialisasi->nama_spesialisasi == 'Makanan & Minuman' ? 'required' : ''); ?>>Makanan & Minuman</option>
                                                <option value="Konveksi" <?php echo e($spesialisasi->nama_spesialisasi == 'Konveksi' ? 'required' : ''); ?>>Konveksi</option>
                                                <option value="Lain" <?php echo e($spesialisasi->nama_spesialisasi == 'Lain' ? 'required' : ''); ?>>Lain</option>
                                            </select>
                                            <select class="form-select mb-3" aria-label="Default select example" name="tingkatan">
                                                <option selected><?php echo e($spesialisasi->tingkatan); ?></option>
                                                <option value="Pemula" <?php echo e($spesialisasi->tingkatan == 'Pemula' ? 'required' : ''); ?>>Pemula</option>
                                                <option value="Menengah" <?php echo e($spesialisasi->tingkatan == 'Menengah' ? 'required' : ''); ?>>Menengah</option>
                                                <option value="Profesional" <?php echo e($spesialisasi->tingkatan == 'Profesional' ? 'required' : ''); ?>>Profesional</option>
                                            </select>
                                            <div class="form-floating mb-3">
                                                <textarea class="form-control" id="deskripsi_singkat" type="text" minlength="12" maxlength="255" placeholder="Masukkan alamat detail bantuan"
                                                name="deskripsi_singkat" ><?php echo e($spesialisasi->deskripsi_singkat); ?></textarea>
                                                <label for="deskripsi_singkat">Deskripsi Singkat</label>
                                            </div>
                                            <div class="modal-footer">
                                                <a href="/profile" type="button" class="btn btn-secondary  data-bs-dismiss="modal">Keluar</a>
                                                <button type="submit" class="btn btn-primary ms-3">Simpan</button>
                                            </div>

                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>

    </body>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nehru Iliomar\OneDrive\Documents\Semester 4\Pemrograman Web\Hexsam\solbat\resources\views/update_spesialisasi.blade.php ENDPATH**/ ?>